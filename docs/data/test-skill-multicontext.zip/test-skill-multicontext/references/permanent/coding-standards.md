# Coding Standards

- Use TypeScript
- Write tests first
- Follow conventional commits
