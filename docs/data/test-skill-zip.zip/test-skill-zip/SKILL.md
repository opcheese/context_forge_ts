---
name: "ZIP Test Skill"
description: "A skill with references"
---

# ZIP Skill Instructions

Follow these steps carefully.
