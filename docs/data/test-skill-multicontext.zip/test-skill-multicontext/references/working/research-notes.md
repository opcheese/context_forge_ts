# Research Notes

Evaluated OAuth2 vs JWT tokens. Going with JWT.
