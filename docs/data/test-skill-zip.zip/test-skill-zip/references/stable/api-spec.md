# API Specification

GET /api/users - returns list of users.
