# Draft Notes

Current progress on the implementation.
