# Code Rules

Always use TypeScript strict mode.
