# API Design

POST /auth/login - authenticate user
POST /auth/signup - create new user
GET /auth/me - get current user
