---
name: "Multi-Step Workflow"
description: "A skill with multiple workflow steps"
---

# Multi-Step Workflow

This skill defines a 3-step workflow for building a feature.
